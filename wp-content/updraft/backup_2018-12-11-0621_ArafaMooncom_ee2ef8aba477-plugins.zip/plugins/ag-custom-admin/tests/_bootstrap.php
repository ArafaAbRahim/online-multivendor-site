<?php
define('AGCA_SITE_URL','http://wp47.dev');
define('AGCA_SITE_USERNAME','admin');
define('AGCA_SITE_PASSWORD','admin');
define('AGCA_SITE_SUBSCRIBER_USERNAME','subscriber');
define('AGCA_SITE_SUBSCRIBER_PASSWORD','subscriber');
define('AGCA_SITE_EDITOR_USERNAME','editor');
define('AGCA_SITE_EDITOR_PASSWORD','editor');
