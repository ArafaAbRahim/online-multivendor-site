<template id="ame-dashboard-widget-template">
	This is the dashboard widget template.
</template>
